package com.example.instalol

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
